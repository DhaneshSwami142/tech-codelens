# Global Rules (apply to every workflow)

One run per application (Java repo). Several Java repos can sit in the workspace; `init` creates one independent run per repo, each with its own state, gates, limits and output folder. Keep the Java repo and this toolkit in the same folder and run `.\migkit` from the toolkit folder. Each run has its own `standards.yaml` (copied from `standards/standards.yaml` or a file you supply). Run state lives in `.migration/<app>/` inside the toolkit folder (or `--runs`/`$MIGKIT_RUNS`). Anything the standards or run config already define is applied and logged as `unchanged`; the agent does not ask about it in chat. Undefined items become unresolved items.

## 2. Parity definition
The Python service must match Java on:
- API contract: paths, methods, payloads, status codes, error shapes
- Business logic
- DB side effects
- Messaging side effects
- Security behavior

Only items in the `approved deviations list` (Workflow 2, Gate B) may differ. Anything else is an unapproved deviation and a defect.

## 3. State and resume
Each workflow writes:
- a checkpoint (`state.json`, updated via `migkit step`) at every module/step boundary,
- a machine-readable output (JSON or YAML, validated against `schemas/`),
- a human-readable summary (`summary.md`).

A failed run resumes from the last checkpoint (`migkit resume`); completed steps are never redone unless inputs changed.

## 4. Audit log
`.migration/<app>/audit.jsonl`, append-only. Record every decision, user confirmation, assumption, and deviation with a UTC timestamp, the workflow, and the actor (`agent` or user name).

## 5. Unresolved items
The agent never guesses. Anything below the confidence threshold (default 0.8, set in the standards file) goes to `unresolved-items.json` with: id, workflow, source reference, question, candidate answers, confidence, risk, status (`open|resolved|accepted`), resolver. Human review is required before a gate passes.

## 6. Limits
Per workflow: `max_fix_iterations` and `token_budget` (standards file, overridable in run config). On breach: stop, mark `escalated`, write the reason to the audit log, and hand the state to a human. No silent extension.

## 7. Data governance
Before any code or data goes to an LLM, pass it through `migkit scrub`: secrets, credentials, tokens, private keys, connection strings, emails, card/SSN-like patterns. Golden-master samples must be sanitized at capture time. Scrubbing is a precondition, not a best effort: if scrubbing fails, the content is not sent.

## 8. Chunking
Work module by module (a module = a package/bounded context sized to fit the context window, listed in the W1 traceability seed). Never load the whole repo in one pass. Cross-module facts travel via the knowledge base, not via raw code.

## 9. Gates
- Gate A (light): user confirms W1 analysis complete; unresolved items resolved or accepted.
- Gate B (hard): explicit approval of the W2 decision register. W3 cannot start without it.
- Gate C (hard): user reviews the W5 accuracy report and unresolved items and signs off.

Gate decisions are recorded with `migkit gate` and the audit log.
