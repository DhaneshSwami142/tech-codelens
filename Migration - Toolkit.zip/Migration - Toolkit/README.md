# Java to Python Migration Workflow Suite

A project-level toolkit. Put it in the same folder as the Java repo you want to migrate, and run `.\migkit` from the toolkit folder.

```
W0 Setup -> W1 Analysis [Gate A] -> W2 Decisions [Gate B, hard]
   -> W3 Migration -> W4 Parity -> W5 Tests/Report [Gate C, hard] -> W6 Docs
```

| # | Workflow | Spec | Key outputs | Gate |
|---|----------|------|-------------|------|
| 0 | Project setup | [00](workflows/00-inventory-and-setup.md) | standards copy, run config, inventory, dependency map | none |
| 1 | Java service analysis | [01](workflows/01-java-analysis.md) | knowledge base, unresolved items, golden master, perf baseline | A (light) |
| 2 | Technology decisions | [02](workflows/02-technology-decisions.md) | decision register, ADRs, library map, approved deviations | B (hard) |
| 3 | Migration | [03](workflows/03-migration.md) | Python codebase, traceability matrix | none |
| 4 | Behavioral parity | [04](workflows/04-parity-verification.md) | parity findings report | none |
| 5 | Tests and accuracy report | [05](workflows/05-tests-and-accuracy.md) | test suite, accuracy report | C (hard) |
| 6 | Documentation | [06](workflows/06-documentation.md) | design doc, ops guide, README | none |

Global rules (parity definition, state/resume, audit, limits, data governance, chunking): [global-rules.md](global-rules.md)

## Layout

```
standards/standards.yaml   the one standards file you fill in; init and validate-standards read it automatically
schemas/                           JSON Schemas for all machine-readable outputs
templates/                         ADR, summary, report templates
tools/migkit.py                    checkpoint, audit, limits, gates, scrubber (stdlib only)
tools/migkit.py + migkit.cmd         the command (use .\migkit in PowerShell)
.migration/<app>/                  (created by init) per-app state: standards.yaml, state.json, audit.jsonl, run-config.json, outputs
```

## Using migkit

Run from the `Migration - Toolkit` folder in PowerShell, with Java repos as sibling folders. Put one or more Java repos in the same folder as the toolkit. `init` creates one run per repo (all repos it finds, or those you name with `--java-source`). Run names are the repo folder names; commands need `--app <name>` when more than one run exists.

```powershell
.\migkit validate-standards                            # checks standards/standards.yaml, lists blank Mandatory fields
.\migkit init --style 1:1                              # one run per Java repo next to the toolkit
.\migkit init --java-source ..\billing ..\orders        # only these repos
.\migkit list                                           # all runs and their next workflow
.\migkit can-start w1 --app billing                     # --app needed when several runs exist
.\migkit start  w1
.\migkit step   w1 "api-catalog:module-billing"
.\migkit usage  w1 --tokens 12000 --iteration
.\migkit audit  --kind assumption "Timezone assumed UTC for Order.createdAt"
.\migkit done   w1
.\migkit gate   A --decision approve --by "name"
.\migkit status
.\migkit resume                                          # shows where to continue
Get-Content Foo.java | .\migkit scrub                            # redact secrets before LLM use
```

`init` refuses to start while Mandatory standards fields are blank (`--allow-incomplete` overrides). `usage` exits with code 2 and marks the workflow `escalated` when the fix-loop or token limit is breached. `can-start` exits 1 if a prerequisite workflow or gate is not satisfied (W3 cannot start without Gate B approval). Step-by-step instructions: [RUNBOOK.md](RUNBOOK.md).
