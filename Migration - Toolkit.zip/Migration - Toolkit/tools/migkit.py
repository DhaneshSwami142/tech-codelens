#!/usr/bin/env python3
"""migkit: state/checkpoint, audit log, limits, gates and secret scrubbing for the
Java -> Python migration workflows. Stdlib only."""
import argparse
import datetime as dt
import json
import os
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WORKFLOWS = ["w0", "w1", "w2", "w3", "w4", "w5", "w6"]
GATE_AFTER = {"w1": "A", "w2": "B", "w5": "C"}    # gate that closes a workflow
GATE_BEFORE = {"w2": "A", "w3": "B", "w6": "C"}   # gate required to start a workflow
HARD = {"B", "C"}
DEFAULT_LIMITS = {"max_fix_iterations": 5, "token_budget": 500000}
STANDARDS = ROOT / "standards" / "standards.yaml"
MANDATORY = [
    "version", "owner", "python.version", "framework.api", "framework.concurrency",
    "framework.server", "framework.validation", "orm.library", "orm.driver", "orm.migrations",
    "package_manager", "quality.lint", "quality.format", "quality.types", "quality.test",
    "quality.coverage_target_percent", "http_client", "observability.logging", "observability.tracing",
    "observability.metrics", "observability.health_endpoints", "config.library", "config.secrets",
    "layout", "deployment.container", "deployment.target", "deployment.ci",
]


def _scalar(val):
    m = re.match(r"""^("(?:[^"\\]|\\.)*"|'[^']*')\s*(#.*)?$""", val)
    if m:
        return m.group(1)[1:-1]
    val = re.sub(r"\s+#.*$", "", val).strip()
    if val.startswith("["):
        try:
            return json.loads(val)
        except ValueError:
            return val
    if val in ("true", "false"):
        return val == "true"
    if re.fullmatch(r"-?\d+", val):
        return int(val)
    if re.fullmatch(r"-?\d+\.\d+", val):
        return float(val)
    return val


def parse_standards(path):
    """Minimal parser for the standards file (nested maps, scalars, inline lists, one block scalar)."""
    out, stack = {}, [(-1, {})]
    stack[0] = (-1, out)
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    i = 0
    while i < len(lines):
        raw = lines[i]
        i += 1
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip())
        key, _, val = raw.strip().partition(":")
        val = val.strip()
        while stack[-1][0] >= indent:
            stack.pop()
        cur = stack[-1][1]
        if val.startswith("|"):
            block = []
            while i < len(lines) and (not lines[i].strip() or len(lines[i]) - len(lines[i].lstrip()) > indent):
                block.append(lines[i].strip())
                i += 1
            cur[key] = "\n".join(b for b in block if b)
        elif val == "" or val.startswith("#"):
            cur[key] = {}
            stack.append((indent, cur[key]))
        else:
            cur[key] = _scalar(val)
    return out


def get_path(d, dotted):
    for k in dotted.split("."):
        if not isinstance(d, dict) or k not in d:
            return None
        d = d[k]
    return d


def missing_mandatory(std):
    return [k for k in MANDATORY if get_path(std, k) in (None, "", [], {})]


def now():
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def run_dir(app, runs):
    return Path(runs) / app


def load(app, runs):
    p = run_dir(app, runs) / "state.json"
    if not p.exists():
        sys.exit(f"no run for '{app}'; run: migkit init --app {app}")
    return json.loads(p.read_text(encoding="utf-8"))


def save(app, runs, st):
    p = run_dir(app, runs) / "state.json"
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(st, indent=2), encoding="utf-8")
    os.replace(tmp, p)  # atomic: a crash never leaves a half-written checkpoint


def audit(app, runs, kind, message, workflow=None, actor="agent", **extra):
    entry = {"ts": now(), "kind": kind, "workflow": workflow, "actor": actor, "message": message, **extra}
    with open(run_dir(app, runs) / "audit.jsonl", "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


# ---------- scrubber ----------
SCRUB_RULES = [
    (r"-----BEGIN [A-Z ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z ]*PRIVATE KEY-----", "[REDACTED_PRIVATE_KEY]"),
    (r"\beyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\b", "[REDACTED_JWT]"),
    (r"\bAKIA[0-9A-Z]{16}\b", "[REDACTED_AWS_KEY]"),
    (r"(?i)\b(bearer|basic)\s+[A-Za-z0-9._~+/=-]{12,}", r"\1 [REDACTED_TOKEN]"),
    (r"(?i)(jdbc:[a-z0-9]+://[^\s\"']*?[?&;](?:password|pwd)=)[^&;\s\"']+", r"\1[REDACTED]"),
    (r"(?i)\b([a-z][a-z0-9+.-]*://[^\s/:@\"']+:)[^\s/@\"']+(@)", r"\1[REDACTED]\2"),
    (r"(?i)((?:password|passwd|pwd|secret|api[_-]?key|access[_-]?key|client[_-]?secret|token|auth[_-]?token)"
     r"[\"']?\s*[:=]\s*[\"']?)[^\s\"',;}]{3,}", r"\1[REDACTED]"),
    (r"\b\d{3}-\d{2}-\d{4}\b", "[REDACTED_SSN]"),
    (r"\b(?:\d[ -]?){13,19}\b", "[REDACTED_CARD]"),
    (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", "[REDACTED_EMAIL]"),
]


def scrub(text):
    for pat, rep in SCRUB_RULES:
        text = re.sub(pat, rep, text)
    return text


# ---------- commands ----------
BUILD_FILES = ("pom.xml", "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts")


def detect_java_repos():
    """All Java repos placed next to the toolkit folder (siblings holding a Maven/Gradle build file)."""
    cands = [c for c in sorted(ROOT.parent.iterdir())
             if c.is_dir() and c.resolve() != ROOT and any((c / b).exists() for b in BUILD_FILES)]
    if not cands:
        sys.exit(f"no Java repo found next to the toolkit in {ROOT.parent}; pass --java-source <path>")
    return cands


def existing_runs(runs):
    r = Path(runs)
    return sorted(c.name for c in r.iterdir() if (c / "state.json").exists()) if r.is_dir() else []


def default_app(runs):
    """The only existing run, if there is exactly one; otherwise the user must pass --app."""
    found = existing_runs(runs)
    if len(found) == 1:
        return found[0]
    sys.exit("pass --app <name>; existing runs: " + (", ".join(found) or "none (run migkit init first)"))


def init_one(a, java, std, src, missing):
    """Create <runs>/<app>/ for one Java repo. Returns False if the run already exists."""
    app = a.app or java.resolve().name
    python_out = a.python_out or str(ROOT.parent / (app + "-python"))
    d = run_dir(app, a.runs)
    if (d / "state.json").exists():
        print(f"[{app}] already initialised, skipped (use resume)")
        return False
    d.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, d / "standards.yaml")
    dflt = std.get("defaults", {})
    limits = {"max_fix_iterations": dflt.get("max_fix_iterations", DEFAULT_LIMITS["max_fix_iterations"]),
              "token_budget": dflt.get("token_budget_per_workflow", DEFAULT_LIMITS["token_budget"])}
    cfg = {"app": app, "java_source_dir": str(java.resolve()),
           "python_output_dir": str(Path(python_out).resolve()),
           "migration_style": a.style or dflt.get("migration_style", "1:1"),
           "confidence_threshold": dflt.get("confidence_threshold", 0.8), "limits": limits}
    (d / "run-config.json").write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    st = {"app": app, "created": now(), "limits": limits, "gates": {},
          "workflows": {w: {"status": "pending", "last_step": None, "steps_done": [],
                            "iterations": 0, "tokens": 0, "updated": now()} for w in WORKFLOWS}}
    save(app, a.runs, st)
    audit(app, a.runs, "init", f"run initialised for {app}", standards=str(src), missing_mandatory=missing)
    print(f"[{app}] initialised {d}")
    print(f"  Java source:   {java.resolve()}")
    print(f"  Python output: {Path(python_out).resolve()}")
    return True


def cmd_init(a):
    """One run per Java repo: all repos next to the toolkit by default, or those given with --java-source."""
    repos = [Path(x) for x in a.java_source] if a.java_source else detect_java_repos()
    for r in repos:
        if not r.is_dir():
            sys.exit(f"Java source not found: {r}")
    if len(repos) > 1 and (a.app or a.python_out):
        sys.exit("--app and --python-out apply to a single repo; each repo gets its own name and <name>-python output")
    src = Path(a.standards) if a.standards else STANDARDS
    if not src.exists():
        sys.exit(f"standards file not found: {src}")
    std = parse_standards(src)
    missing = missing_mandatory(std)
    if missing and not a.allow_incomplete:
        sys.exit("standards incomplete; fill these Mandatory fields in " + str(src) + ":" + chr(10) + "  " + (chr(10) + "  ").join(missing))
    names = [r.resolve().name for r in repos]
    if len(set(names)) != len(names):
        sys.exit("Java repo folder names must be unique: " + ", ".join(names))
    print(f"{len(repos)} Java repo(s): " + ", ".join(names))
    for r in repos:
        init_one(a, r, std, src, missing)
    if missing:
        print("WARNING: incomplete standards: " + ", ".join(missing))


def cmd_list(a):
    runs = existing_runs(a.runs)
    if not runs:
        print("no runs yet; run: migkit init")
    for name in runs:
        st = load(name, a.runs)
        cur = next((w for w in WORKFLOWS if st["workflows"][w]["status"] != "done"), "all done")
        print(f"{name}: next/active = {cur}")


def cmd_w3_steps(a):
    """Write .migration/<app>/w3/VERIFY-STEPS.md from the template with every value filled in."""
    d = run_dir(a.app, a.runs)
    cfg = json.loads((d / "run-config.json").read_text(encoding="utf-8"))
    health = get_path(parse_standards(d / "standards.yaml"), "observability.health_endpoints") or []
    if isinstance(health, str):
        health = [health]
    base = f"http://localhost:{a.port}"
    prereq = a.prereq or ["None: the app needs nothing else before it starts."]
    values = {
        "APP": a.app,
        "DATE": dt.date.today().isoformat(),
        "OUTPUT_DIR": str(Path(cfg["python_output_dir"])),
        "TOOLKIT_DIR": str(ROOT),
        "AUDIT_LOG": str(d / "audit.jsonl"),
        "MYPY_TARGET": a.mypy_target,
        "START_COMMAND": f"uv run uvicorn {a.module} --port {a.port}",
        "HEALTH_COMMANDS": chr(10).join(f"Invoke-RestMethod {base}{h}" for h in health) or f"Invoke-RestMethod {base}/",
        "PREREQUISITES": chr(10).join(f"- {p}" for p in prereq),
    }
    text = (ROOT / "templates" / "w3-verify-steps.md").read_text(encoding="utf-8")
    for k, v in values.items():
        text = text.replace("{{" + k + "}}", v)
    left = re.findall(r"\{\{\w+\}\}", text)
    if left:
        sys.exit("unfilled placeholders: " + ", ".join(left))
    out = d / "w3"
    out.mkdir(exist_ok=True)
    (out / "VERIFY-STEPS.md").write_text(text, encoding="utf-8")
    audit(a.app, a.runs, "note", "VERIFY-STEPS.md written", "w3")
    print(f"written: {out / 'VERIFY-STEPS.md'}")


def w0_problems(app, runs):
    d = run_dir(app, runs)
    problems = []
    if not (d / "state.json").exists():
        return [f"no run found for '{app}' (run .\\migkit init)"]
    std = d / "standards.yaml"
    if not std.exists():
        problems.append("standards.yaml missing in the run folder")
    else:
        missing = missing_mandatory(parse_standards(std))
        if missing:
            problems.append("standards.yaml has blank Mandatory fields: " + ", ".join(missing))
    cfg = {}
    try:
        cfg = json.loads((d / "run-config.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        problems.append("run-config.json missing or not valid JSON")
    for key in ("java_source_dir", "python_output_dir", "migration_style"):
        if cfg and not cfg.get(key):
            problems.append(f"run-config.json is missing '{key}'")
    for name in ("inventory.json", "dependency-map.json"):
        f = d / name
        try:
            if not json.loads(f.read_text(encoding="utf-8")):
                problems.append(f"{name} is empty")
        except OSError:
            problems.append(f"{name} has not been written")
        except ValueError:
            problems.append(f"{name} is not valid JSON")
    out = Path(cfg.get("python_output_dir") or "")
    if cfg.get("python_output_dir") and out.is_dir() and any(out.iterdir()):
        confirmed = any(json.loads(line).get("kind") == "confirmation"
                        for line in (d / "audit.jsonl").read_text(encoding="utf-8").splitlines() if line.strip())
        if not confirmed:
            problems.append(f"Python output folder is not empty ({out}); empty it or log the user's confirmation")
    return problems


def cmd_check_w0(a):
    """Print a fixed success/failure message for Workflow 0 (one run, or every run when --app is omitted)."""
    apps = [a.app] if a.app else existing_runs(a.runs)
    if not apps:
        print("FAILED: no runs found. Run .\\migkit init first.")
        sys.exit(1)
    bad = 0
    for app in apps:
        problems = w0_problems(app, a.runs)
        if problems:
            bad += 1
            print(f"FAILED: Workflow 0 (Project Setup) is NOT complete for '{app}'.")
            for p in problems:
                print(f"  - {p}")
            print(f"Fix the items above, then run: .\\migkit check-w0 --app {app}")
        else:
            audit(app, a.runs, "check", "Workflow 0 checks passed", "w0")
            print(f"SUCCESS: Workflow 0 (Project Setup) is complete for '{app}'.")
            print("  Standards validated, run config created, inventory and dependency map written.")
            print(f"Next: .\\migkit done w0 --app {app}, then start Workflow 1 (Java service analysis).")
    sys.exit(1 if bad else 0)


def cmd_validate_standards(a):
    src = Path(a.file) if a.file else STANDARDS
    missing = missing_mandatory(parse_standards(src))
    if missing:
        print("INCOMPLETE. Mandatory fields blank:\n  " + "\n  ".join(missing))
        sys.exit(1)
    print("standards ok")


def check_start(st, w):
    i = WORKFLOWS.index(w)
    if i > 0 and st["workflows"][WORKFLOWS[i - 1]]["status"] != "done":
        return f"{WORKFLOWS[i - 1]} is not done"
    g = GATE_BEFORE.get(w)
    if g and st["gates"].get(g, {}).get("decision") != "approve":
        return f"Gate {g} not approved"
    return None


def cmd_can_start(a):
    st = load(a.app, a.runs)
    why = check_start(st, a.workflow)
    if why:
        print(f"BLOCKED: {why}")
        sys.exit(1)
    print("ok")


def cmd_start(a):
    st = load(a.app, a.runs)
    w = st["workflows"][a.workflow]
    if w["status"] == "escalated":
        sys.exit("workflow escalated; a human must clear it (migkit reset)")
    if w["status"] == "pending":
        why = check_start(st, a.workflow)
        if why:
            sys.exit(f"BLOCKED: {why}")
    w.update(status="running", updated=now())
    save(a.app, a.runs, st)
    audit(a.app, a.runs, "start", "workflow started/resumed", a.workflow)
    print(f"{a.workflow} running; steps done: {len(w['steps_done'])}")


def cmd_step(a):
    st = load(a.app, a.runs)
    w = st["workflows"][a.workflow]
    if a.step not in w["steps_done"]:
        w["steps_done"].append(a.step)
    w.update(last_step=a.step, updated=now())
    save(a.app, a.runs, st)
    audit(a.app, a.runs, "checkpoint", a.step, a.workflow)
    print("checkpointed")


def cmd_usage(a):
    st = load(a.app, a.runs)
    w = st["workflows"][a.workflow]
    w["tokens"] += a.tokens
    if a.iteration:
        w["iterations"] += 1
    w["updated"] = now()
    lim = st["limits"]
    reason = None
    if w["iterations"] > lim["max_fix_iterations"]:
        reason = f"fix-loop limit exceeded ({w['iterations']}>{lim['max_fix_iterations']})"
    elif w["tokens"] > lim["token_budget"]:
        reason = f"token budget exceeded ({w['tokens']}>{lim['token_budget']})"
    if reason:
        w["status"] = "escalated"
        save(a.app, a.runs, st)
        audit(a.app, a.runs, "escalation", reason, a.workflow)
        print(f"ESCALATED: {reason}")
        sys.exit(2)
    save(a.app, a.runs, st)
    print(f"tokens={w['tokens']}/{lim['token_budget']} iterations={w['iterations']}/{lim['max_fix_iterations']}")


def cmd_done(a):
    st = load(a.app, a.runs)
    st["workflows"][a.workflow].update(status="done", updated=now())
    save(a.app, a.runs, st)
    audit(a.app, a.runs, "done", "workflow completed", a.workflow)
    print("done")


def cmd_gate(a):
    st = load(a.app, a.runs)
    if a.gate in HARD and a.by in ("", "agent"):
        sys.exit(f"Gate {a.gate} is hard: needs a named human via --by")
    st["gates"][a.gate] = {"decision": a.decision, "by": a.by, "ts": now(), "note": a.note}
    save(a.app, a.runs, st)
    audit(a.app, a.runs, "gate", f"Gate {a.gate} {a.decision}", actor=a.by, note=a.note)
    print(f"Gate {a.gate}: {a.decision}")


def cmd_audit(a):
    load(a.app, a.runs)
    audit(a.app, a.runs, a.kind, a.message, a.workflow, a.actor)
    print("logged")


def cmd_status(a):
    st = load(a.app, a.runs)
    for w, v in st["workflows"].items():
        print(f"{w}: {v['status']:<9} last_step={v['last_step']} tokens={v['tokens']} iter={v['iterations']}")
    for g, v in st["gates"].items():
        print(f"Gate {g}: {v['decision']} by {v['by']} at {v['ts']}")


def cmd_resume(a):
    st = load(a.app, a.runs)
    for w in WORKFLOWS:
        v = st["workflows"][w]
        if v["status"] in ("running", "escalated"):
            print(f"resume {w} ({v['status']}) after step '{v['last_step']}'; {len(v['steps_done'])} steps done")
            return
        if v["status"] == "pending":
            why = check_start(st, w)
            print(f"next: {w}" + (f" (blocked: {why})" if why else ""))
            return
    print("all workflows done")


def cmd_reset(a):
    st = load(a.app, a.runs)
    w = st["workflows"][a.workflow]
    w.update(status="running", iterations=0 if a.clear_counters else w["iterations"],
             tokens=0 if a.clear_counters else w["tokens"], updated=now())
    save(a.app, a.runs, st)
    audit(a.app, a.runs, "reset", "escalation cleared by human", a.workflow, a.by, counters_cleared=a.clear_counters)
    print("cleared")


def cmd_scrub(a):
    sys.stdout.write(scrub(sys.stdin.read()))


def main(argv=None):
    p = argparse.ArgumentParser(prog="migkit")
    p.add_argument("--runs", default=os.environ.get("MIGKIT_RUNS", str(ROOT / ".migration")),
                   help="run state dir (default: .migration inside the toolkit folder, or $MIGKIT_RUNS)")
    sub = p.add_subparsers(dest="cmd", required=True)

    def add(name, fn, app=True, workflow=False):
        s = sub.add_parser(name)
        if app:
            s.add_argument("--app", default=None, help="default: the Java repo name (init) or the only existing run")
        if workflow:
            s.add_argument("workflow", choices=WORKFLOWS)
        s.set_defaults(fn=fn)
        return s

    s = add("init", cmd_init)
    s.add_argument("--java-source", nargs="+", action="extend", default=None, help="one or more Java repo paths (default: every Java repo next to the toolkit)"); s.add_argument("--python-out", default="")
    s.add_argument("--style", choices=["1:1", "cleanup"]); s.add_argument("--standards", default="")
    s.add_argument("--allow-incomplete", action="store_true")
    s = add("validate-standards", cmd_validate_standards, app=False); s.add_argument("--file", default="")
    add("can-start", cmd_can_start, workflow=True)
    add("start", cmd_start, workflow=True)
    s = add("step", cmd_step, workflow=True); s.add_argument("step")
    s = add("usage", cmd_usage, workflow=True)
    s.add_argument("--tokens", type=int, default=0); s.add_argument("--iteration", action="store_true")
    add("done", cmd_done, workflow=True)
    s = add("gate", cmd_gate); s.add_argument("gate", choices=["A", "B", "C"])
    s.add_argument("--decision", choices=["approve", "reject"], required=True)
    s.add_argument("--by", default=""); s.add_argument("--note", default="")
    s = add("audit", cmd_audit); s.add_argument("message"); s.add_argument("--kind", default="note")
    s.add_argument("--workflow", default=None); s.add_argument("--actor", default="agent")
    add("list", cmd_list, app=False)
    s = add("check-w0", cmd_check_w0)
    s = add("w3-steps", cmd_w3_steps)
    s.add_argument("--module", required=True, help="uvicorn target, e.g. library_master.main:app")
    s.add_argument("--port", type=int, default=8000)
    s.add_argument("--mypy-target", default="src")
    s.add_argument("--prereq", action="append", default=[], help="one prerequisite line; repeat for several")
    add("status", cmd_status)
    add("resume", cmd_resume)
    s = add("reset", cmd_reset, workflow=True); s.add_argument("--by", required=True)
    s.add_argument("--clear-counters", action="store_true")
    add("scrub", cmd_scrub, app=False)
    a = p.parse_args(argv)
    if hasattr(a, "app") and a.app is None and a.cmd not in ("init", "check-w0"):
        a.app = default_app(a.runs)
    a.fn(a)


if __name__ == "__main__":
    main()
