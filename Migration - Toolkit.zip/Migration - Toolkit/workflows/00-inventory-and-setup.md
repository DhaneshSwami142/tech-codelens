# Workflow 0: Project Setup

**Purpose:** set up the migration run for the Java repo you are in. Each run carries its own `standards.yaml`.
**Applies:** [global-rules.md](../global-rules.md)

No questions are asked in chat for anything the standards file already answers.

## Steps

1. **Standards.** Fill the Mandatory fields of [standards.yaml](../standards/standards.yaml), or point to a ready-made standards file.
2. **Initialise.** From the toolkit folder (the Java repos sit next to it; one run is created per repo, and `--java-source <path> [<path> ...]` limits it to the repos you name):
   ```powershell
   .\migkit init --style 1:1
   ```
   `init` validates the standards (it stops and lists blank Mandatory fields), copies them to `.migration/<app>/standards.yaml`, writes `run-config.json` (Java source, Python output dir, migration style, limits), and creates `state.json` and the audit log.
3. **Inventory.** Language/framework versions, build tool, size (LOC, modules, endpoints), owners (from `CODEOWNERS` or build metadata; if absent, an unresolved item, not a question), detected DB and messaging. Output `inventory.json`.
4. **Map dependencies.** Service-to-service calls, shared DBs, queues/topics, shared internal JARs. When the workspace holds several Java repos, also record which of them call each other or share libraries (each other's names appear as nodes), so the user can choose the order. Output `dependency-map.json`.
5. **Record conflicts with standards** (e.g. the app uses H2 but `orm.driver` is asyncpg) as unresolved items for Workflow 2. Do not ask now.

## Completion check and user message (mandatory)
When steps 1-5 are finished, the agent runs:
```powershell
.\migkit check-w0            # all runs; add --app <name> for one
```
and shows the command's output to the user **exactly as printed**, without rewording or adding its own verdict. The messages are fixed by the tool:
- **Success:** `SUCCESS: Workflow 0 (Project Setup) is complete for '<app>'.` plus the next command (`.\migkit done w0 --app <app>`, then Workflow 1).
- **Failure:** `FAILED: Workflow 0 (Project Setup) is NOT complete for '<app>'.` followed by one `-` line per problem (blank standards field, missing run config, `inventory.json` or `dependency-map.json` not written, non-empty Python output folder) and the command to re-run after fixing.

On failure the agent fixes what it can (e.g. writes the missing file), re-runs the check, and stops with the failure output if it cannot. It never reports success itself.

## Outputs
`standards.yaml` (copy), `run-config.json`, `inventory.json`, `dependency-map.json`. Schema: `schemas/run-config.schema.json`.

## Checkpoints
`a1-init`, `a2-inventory`, `a3-dependencies`, `a4-conflicts`.

## Exit criteria
Standards valid, run config present, inventory and dependency map written, Python output dir empty or confirmed by the user (logged).
