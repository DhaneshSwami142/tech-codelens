# Workflow 2: Technology Decisions and Approval Gate

**Purpose:** decide everything that will differ between Java and Python.
**Inputs:** W1 `dependencies.json`, `integrations.json`, `security.json`; standards file; W1 performance baseline.
**Output dir:** `.migration/<app>/w2/`

## Step 1: Library mapping table (`library-map.json`)
For each detected Java library, propose the Python equivalent. Per row:
- Java lib + version, purpose
- Alternatives considered
- Recommendation + rationale
- **Pinned version, looked up live** (PyPI), never from memory
- Python compatibility (target version supported)
- Maintenance health (last release, open issues, maintainers)
- License (flag copyleft/incompatible)
- Known CVEs (OSV / advisory DB lookup)
- Behavioral differences vs Java library (serialization, rounding, null handling, transaction semantics)

Check the chosen Python version's EOL status live; warn if EOL within 12 months.

## Step 2: Questions (pre-filled from the standards file)
Python version; sync/async and worker model; API framework; ORM, DB driver, migration tool; whether Java and Python share the DB during cutover (drives schema-change rules: additive only, no destructive changes); validation/serialization; package manager; test framework, linter, type checker; HTTP client, messaging client, auth approach; logging/metrics/tracing; config and secrets; project layout; deployment target, container, CI/CD; replacement for shared internal Java libs; performance thresholds vs the Java baseline.

## Step 3: Approval rule
- **Needs approval** (differs from Java): library/version changes, concurrency model, auth mechanism, external API client changes, serialization behavior differences, ORM/transaction semantics.
- **Skipped but logged as `unchanged`:** business rules, endpoint behavior, status codes, error shapes, etc.

Each decision row: `id, topic, java_state, python_state, differs (bool), needs_approval (bool), rationale, risk, status (proposed|approved|rejected|unchanged)`.

## Step 4: ADRs
One ADR per confirmed decision, from [adr-template.md](../templates/adr-template.md), in `w2/adrs/ADR-NNNN-<slug>.md`.

## Outputs
`decision-register.json`, `adrs/`, `library-map.json`, `approved-deviations.json`, `summary.md`.

## Gate B (hard)
Present the full register. Nothing proceeds without explicit user approval of the whole register. Record with `migkit gate B --decision approve --by <name>`. Any later change to a decision reopens Gate B.
