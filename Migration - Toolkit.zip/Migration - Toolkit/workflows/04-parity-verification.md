# Workflow 4: Behavioral Parity Verification

**Purpose:** prove the Python service behaves like the Java service, independent of the tests W5 generates.
**Inputs:** W1 knowledge base + golden master, W2 approved deviations, W3 code and matrix.

## Checks
1. **Contract diff.** Java OpenAPI (W1) vs OpenAPI generated from Python: paths, methods, schemas, required/optional, validation constraints, status codes, error formats.
2. **Logic review.** Each W1 business-logic item vs its Python counterpart: branches, calculations, null/edge handling, rounding (`BigDecimal` -> `Decimal`), date-time/timezone, Optional.
3. **Side-effect review.** DB writes, queries, transaction boundaries, messages published/consumed (topic, key, payload, headers), outbound calls, cache and scheduler behavior.
4. **Security review.** AuthN/AuthZ rules, role checks, filter order, token handling, CORS/CSRF, error responses for 401/403.
5. **Differential run (where possible).** Replay golden-master requests against the Python service; diff responses (normalize volatile fields: timestamps, generated IDs) and observed side effects. Record where not possible and why.

## Classification
Every finding: `match | approved_deviation (cite decision ID) | unapproved_deviation`.
Unapproved deviations are fixed through W3, then re-verified. Re-verification is bounded by `max_fix_iterations`; on cap, escalate.

## Outputs
`w4/parity-findings.json` (finding id, Java ID, Python ref, category, classification, evidence, severity, status), `w4/summary.md`, updated `traceability-matrix.json`.

## Exit criteria
Zero open unapproved deviations, or each is escalated and listed in unresolved items with risk.
