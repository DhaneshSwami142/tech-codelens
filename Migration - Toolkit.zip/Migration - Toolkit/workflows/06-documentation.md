# Workflow 6: Documentation

**Purpose:** produce the docs a new team needs. **Precondition:** Gate C approved.
**Output dir:** `.migration/<app>/w6/` and copied into the Python repo (`docs/`, `README.md`).

## Document 1: Design and Architecture (`design-architecture.md`)
- As-is (Java) and to-be (Python) architecture diagrams (Mermaid)
- Sequence diagrams for key flows
- API catalog and data model
- Java-to-Python mapping (library map + traceability summary)
- ADRs (link/embed)
- Deviations, risks, open items
- Test coverage summary

## Document 2: Setup and Operations Guide (`setup-operations-guide.md`)
- Prerequisites and environment setup (package manager, Python version)
- Configuration and environment variables; how secrets are supplied
- Run locally, run tests, lint
- DB setup and migrations
- Docker build/run; deployment steps
- Health, logging, monitoring endpoints
- Troubleshooting and runbook
- **Cutover and rollback plan:** strangler pattern or canary, dual-run, feature flags, rollback steps, exit criteria per stage, shared-DB considerations

## README
Short project overview, quick start, links to both documents.

## Rules
Every command in the docs must have been executed successfully against the generated project (record in audit log). Do not document anything unverified; list it under open items instead. Never include secrets.

## Outputs
Both documents plus README.
