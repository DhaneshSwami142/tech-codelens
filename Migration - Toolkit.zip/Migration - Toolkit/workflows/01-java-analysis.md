# Workflow 1: Java Service Analysis (Knowledge Base)

**Purpose:** build the structured knowledge base all later workflows use.
**Inputs:** run config, Java source. **Process module by module**; scrub before any LLM call.
**Output dir:** `.migration/<app>/w1/`

## Steps and outputs

| Step | What to capture | File |
|------|-----------------|------|
| 1. API catalog | OpenAPI (extract from springdoc if present, else generate from controllers): endpoints, request/response models, Bean Validation rules, status codes, error formats | `api-catalog.yaml` |
| 2. Business logic catalog | Per service/class: rules, branches, calculations, edge cases. Flag `BigDecimal` (scale, RoundingMode, MathContext), date-time/timezone (`LocalDateTime` vs `Instant`, default zone), null and `Optional` behavior, checked exceptions | `business-logic.json` |
| 3. Data layer | Entities, relationships, schema, JPQL/native queries, `@Transactional` boundaries (propagation, isolation, readOnly, rollbackFor), Flyway/Liquibase migrations, pool config, lazy/eager fetch, cascade, optimistic locking | `data-layer.json` |
| 4. Integrations | Outbound HTTP/Feign (timeouts, retries, error decoders), Kafka/JMS producers and consumers (topics, keys, serializers, ack, DLQ), schedulers (cron, locks), caches (TTL, eviction), file/object storage | `integrations.json` |
| 5. Security | Spring Security config, filter chain, roles/authorities, method security, token/JWT handling, CORS/CSRF, password encoding | `security.json` |
| 6. Cross-cutting | AOP aspects, interceptors, filters, `@ControllerAdvice` handlers, profiles/config, secret sources, logging (MDC), metrics, health endpoints | `cross-cutting.json` |
| 7. Dependencies | Parse `pom.xml`/`build.gradle` with resolved versions, including internal shared libs | `dependencies.json` |
| 8. Dead code / tech debt | Unused endpoints/classes/config, duplicated logic. Flag each for the 1:1 vs cleanup decision (no removal in W1) | `dead-code.json` |
| 9. Baseline capture | Java latency (p50/p95/p99), throughput, memory per endpoint; real request/response samples, **sanitized** | `performance-baseline.json`, `golden-master/` |
| 10. Traceability seed | Unique ID for every endpoint and class (`EP-0001`, `CL-0001`, ...) with module, file, kind | `traceability-seed.json` |

Every item has an ID, a source reference (file:line), and a confidence score. Items below the confidence threshold go to `unresolved-items.json`.

## Golden-master format
One file per sample: request (method, path, headers minus secrets, body), response (status, headers, body), observed side effects (DB rows changed, messages published, outbound calls), scenario tag, linked endpoint ID. Include negative/error cases and edge cases, not only happy paths.

## Checkpoints
One per step per module: `w1:<step>:<module>`.

## Outputs
Knowledge base (JSON/YAML above), `summary.md`, `unresolved-items.json`, golden-master dataset, performance baseline.

## Gate A (light)
User confirms the analysis is complete and all unresolved items are `resolved` or `accepted`. Record with `migkit gate A`.
