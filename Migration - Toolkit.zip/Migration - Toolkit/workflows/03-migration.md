# Workflow 3: Migration (Code Generation)

**Purpose:** write the new Python codebase.
**Precondition:** Gate B approved (`migkit can-start w3` enforces).
**Inputs:** W1 knowledge base, W2 register/ADRs, standards file, run config.

## Steps
1. **Output directory.** Use `python_output_dir` from run config. Stop if non-empty unless the user confirms (log the confirmation).
2. **Scaffold** per approved layout, package manager, and tooling (pyproject, lint/type/test config, pre-commit).
3. **Migrate module by module** in dependency order (domain/models -> repositories -> services -> API -> integrations). Context per module = that module's KB slice + construct rules below. Checkpoint per module.
4. **Preserve business logic exactly.** Apply only approved deviations. For `cleanup` style, remove only items flagged in `dead-code.json` and approved by the user.
5. **Generate** config, logging, health endpoints, auth, DB migration scripts (Alembic; honor shared-DB decision).
6. **Generate** Dockerfile, CI/CD pipeline, deployment manifests.
7. **Build loop** (capped by `max_fix_iterations`): generate -> install -> lint -> type-check -> start app -> fix. On cap, escalate.
8. **Traceability matrix**: `Java ID -> Python element, status (migrated|deviation|removed|pending), confidence`.
9. **Write the user's verification steps** (mandatory, last step). Do not write the file by hand: run the tool, which fills every path and value itself (output folder, toolkit folder, audit log path and app name from the run config; health endpoints from the standards):
   ```powershell
   .\migkit w3-steps --app <app> --module <package.module:app> --port <port> --prereq "<what must exist before start>"
   ```
   - `--module`: the real uvicorn target of the generated project (e.g. `library_master.main:app`). Confirm it by starting the app yourself first.
   - `--port`: the port the app listens on (default 8000).
   - `--prereq`: one line per thing needed before the app starts (database to run or a SQLite/test URL, env vars from `.env.example` with example values, Kafka or other stubs). Repeat the flag for several lines. Omit it only if nothing is needed.
   - `--mypy-target`: only if mypy should not run on `src`.
   The tool writes `.migration/<app>/w3/VERIFY-STEPS.md` and fails if any placeholder is left unfilled. Read the file once and fix the arguments if anything looks wrong.

## Construct rules (Java -> Python)
| Java | Python |
|------|--------|
| Spring DI (`@Autowired`, constructor injection) | Explicit constructor injection; FastAPI `Depends` for request scope; app-scope singletons in a container module |
| AOP aspects / interceptors / filters | Middleware, dependencies, decorators; preserve ordering |
| JPA entities / repositories | SQLAlchemy 2.x models + repository classes; match fetch, cascade, locking, and query semantics; port JPQL/native queries and compare results |
| `@Transactional` | Explicit unit-of-work/session context; preserve propagation, isolation, readOnly, rollback rules (rollback on RuntimeException only unless configured) |
| Bean Validation | Pydantic validators with identical constraints and **identical error messages/shape** |
| Lombok (`@Data`, `@Builder`, ...) | dataclass / pydantic models; reproduce equals/hashCode/toString only if used |
| Jackson (naming, null inclusion, unknown props, date formats, polymorphism) | Pydantic config/aliases/serializers reproducing the exact JSON, including field order and null handling |
| `BigDecimal` | `Decimal` with explicit context; map scale and `RoundingMode` (HALF_UP -> `ROUND_HALF_UP`); never use float |
| `LocalDate/LocalDateTime/ZonedDateTime/Instant` | `date`/naive `datetime`/aware `datetime`/UTC-aware `datetime`; preserve default time zone behavior and serialization format |
| Checked/unchecked exceptions, `@ControllerAdvice` | Domain exceptions + exception handlers reproducing status codes and error bodies |
| `Optional` | `T \| None` with identical empty/null behavior at API boundaries |
| `@Scheduled`, Quartz | APScheduler/Celery beat/cron per ADR; preserve cron, concurrency guards, locks |
| `@KafkaListener`, `@JmsListener` | Consumer loop per ADR; preserve group id, ack mode, retry, DLQ, ordering, idempotency |
| Feign/RestTemplate | httpx client with same timeouts, retries, error mapping |
| Spring Security | Per ADR; same roles, URL/method rules, token validation, CORS/CSRF |
| `application-<profile>.yml` | pydantic-settings with env override; profiles map to env |

Unmapped construct -> do not guess; add to `unresolved-items.json` and mark `pending`.

## Final message to the user (mandatory)
When the workflow ends, the agent prints exactly one of these, then stops:

- **Build loop green:**
  `SUCCESS: Workflow 3 (Migration) generated the Python project for '<app>' at <output dir>. Now verify it yourself: follow the steps in <full path of VERIFY-STEPS.md> (uv sync, ruff, mypy, app start, health checks). When they all pass, continue with Workflow 4.`
- **Loop limit or token budget reached (`migkit usage` exited with code 2):**
  `ESCALATED: Workflow 3 (Migration) stopped for '<app>' because the <fix-loop|token> limit was reached. The last error was: <one line>. Read <audit log path>, fix the cause, then follow step 7 in <full path of VERIFY-STEPS.md> to reset the block.`
  The agent still writes `VERIFY-STEPS.md` (with the real values it has) before printing this.
- **Any other stop** (e.g. output folder not empty and not confirmed, Gate B missing): `FAILED: Workflow 3 (Migration) did not run for '<app>': <reason>.`

The agent never says the project "works" on its own; the user's checks in `VERIFY-STEPS.md` are the proof.

## Outputs
Python codebase in output dir, `traceability-matrix.json`, updated `unresolved-items.json`, `summary.md`, `.migration/<app>/w3/VERIFY-STEPS.md`.

## Exit criteria
Build loop green (install, lint, types, app starts, health OK); no `pending` rows without an unresolved-item entry; `VERIFY-STEPS.md` written with no placeholders left.
