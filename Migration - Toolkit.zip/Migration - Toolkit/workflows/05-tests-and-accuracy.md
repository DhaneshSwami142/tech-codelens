# Workflow 5: Test Suite and Accuracy Report

**Purpose:** deliver the Python test suite and evidence of parity.
**Independence rule:** tests derive from the Java-derived knowledge base and golden-master data, **not** from the Python code.

## Steps
1. **Write tests** into the Python repo (`tests/`): unit, API and contract, integration, negative and error-path, edge-case, security. Cover every endpoint and every scenario in the KB. Each test carries a scenario ID and Java element ID in its marker/docstring (`@pytest.mark.scenario("EP-0012:S03")`).
2. **Run the suite** and measure coverage (target from standards file).
3. **Load test** against the W1 performance baseline using the same scenarios and comparable hardware/data volume; compare to the W2 performance thresholds.
4. **Accuracy report** (`w5/accuracy-report.md` + `.json`):
   - per-endpoint and per-scenario table: Java behavior | Python behavior | test ID | result
   - coverage summary
   - performance comparison vs baseline and thresholds
   - approved deviations
   - open items with risk
5. **Final traceability matrix.**

## Pass criteria
Every identified scenario has a passing test or an approved deviation; coverage target met; performance within thresholds (or accepted deviation). A failing test is a defect to fix via W3/W4 (bounded by `max_fix_iterations`); never weaken or delete a test to pass.

## Outputs
Test suite in Python repo, accuracy report, final traceability matrix.

## Gate C (hard)
User reviews the accuracy report and unresolved items and signs off. `migkit gate C --decision approve --by <name>`.
