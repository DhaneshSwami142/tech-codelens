# Runbook: How to actually run a migration
## Per-project setup

1. Open your AI coding assistant with `<workspace>` as the working directory, so it can see both the Java repo and the toolkit dir.
2. Prepare the standards file: `Migration - Toolkit\standards\standards.yaml` and fill every `#Mandatory` field for the Python project to be generated
3. check it:
   ```powershell
   cd "\Migration - Toolkit"
   ```
   ```powershell
   .\migkit validate-standards
   ```
4. Initialise the run (it re-validates the standards the same way):
   ```powershell
   .\migkit init
   ```
5. Prompt the assistant:
   > Follow `Migration - Toolkit/workflows/00-inventory-and-setup.md` for this repo. Do not ask me questions that standards.yaml answers; log conflicts as unresolved items.

   SUCCESS: Workflow 0 (Project Setup) is complete for '<project_name>'

   FAILED: Workflow 0 (Project Setup) is NOT complete for '<project_name>'. (Check/Confirm on the assistant doubt/queries asked).

6. Check `.migration\<app>\inventory.json` and `dependency-map.json`, then run 
   ```powershell
   migkit done w0
   ```

## Workflow steps

### Step 1: Analyse the Java service (W1)
```powershell
.\migkit start w1
```
Prompt the assistant:
> Follow `Migration - Toolkit/workflows/01-java-analysis.md`. Go module by module. Run `migkit scrub` on code before analysing it. Checkpoint each step with `migkit step`. Never guess: put low-confidence items in unresolved-items.json.

**Gate A:** read `/Migration - Toolkit/.migration/<app>/w1/summary.md`
- Resolve every unresolved item by prompting to assistant as below.
Prompt the assistant:
   > Follow `Migration - Toolkit\.migration\<app>\w1\summary.md` -> "Unresolved Items" mentioned in this W1 Analysis Summary and resolve those by asking questions and doubts(DO NOT ASSUME ANYTHING). If you have resolution then update that into '.\Migration - Toolkit\.migration\<app>\unresolved-items.json.'

- For accepting items run below command
   ```powershell
   .\migkit done w1
   .\migkit gate A --decision approve --by "<your name>"
   ```

### Step 2: Technology decisions (W2)
```powershell
.\migkit start w2
```
Prompt the assistant:
> Follow `Migration - Toolkit/workflows/02-technology-decisions.md`. Look up versions, EOL and CVEs live. Only ask me about items that differ from Java or conflict with standards.yaml.

**Gate B (hard):** review `w2/decision-register.json` and `library-map.json`. Anything you don't approve gets changed and re-presented.
```powershell
.\migkit done w2
.\migkit gate B --decision approve --by "<your name>"
```

### Step 3: Generate the Python code (W3)
```powershell
.\migkit can-start w3
.\migkit start w3
```
Prompt the assistant:
> Follow `Migration - Toolkit/workflows/03-migration.md`. Output dir is in run-config.json. Migrate module by module in dependency order. Run the build loop; record each iteration with `migkit usage w3 --iteration`.

> Follow `Migration - Toolkit/.migration/library-master/w3/VERIFY-STEPS.md` step by step. Run each command, show me the raw output, and fix any failure in the generated code without weakening lint, type or test settings or changing business behaviour. Record each fix attempt with .\migkit usage w3 --iteration --app library-master. If a step needs something you can’t provide, stop and tell me exactly what.

If the loop limit is hit, read the audit log, fix the cause, then:
```powershell
.\migkit reset w3 --by "<your name>" --clear-counters
```

### Step 4: Parity verification (W4)
Prompt the assistant:
> Follow `Migration - Toolkit/workflows/04-parity-verification.md`. Replay the golden-master requests against the running Python service. Classify every finding.

> Fix unapproved deviations in <app-python> so that behaviour matches Java. Don’t change approved deviations. Record each attempt with .\migkit usage w3 --iteration --app <app>.

Stand up the Python service with a copy of the test DB, with stubs or test instances and prompt below.

> Follow `Migration - Toolkit/workflows/04-parity-verification.md`. Replay the golden-master requests against the running Python service. Classify every finding.

### Step 5: Tests and accuracy report (W5)
Prompt the assistant:
> Follow `Migration - Toolkit/workflows/05-tests-and-accuracy.md`. Write tests from the W1 knowledge base and golden master, not from the Python code.

Run the load test on hardware comparable to the Java baseline. **Gate C (hard):** read `w5/accuracy-report.md` and sign off.
```powershell
.\migkit gate C --decision approve --by "<your name>"
```

### Step 6: Documentation (W6)
Prompt the assistant:
> Follow `Migration - Toolkit/workflows/06-documentation.md`. Run every command you document.

## Practical tips
- Use a fresh assistant session per workflow, or per module in W1 and W3. The files in `Migration - Toolkit/.migration/<app>/` carry the state between sessions.
- Review the audit log (`Migration - Toolkit/.migration/<app>/audit.jsonl`) before every gate.
- Add `.migration/` to the Java repo's `.gitignore` unless you want to commit the knowledge base. Never commit golden-master data that isn't sanitized.
- Never point tests at production. Use test DBs and sanitized data.
