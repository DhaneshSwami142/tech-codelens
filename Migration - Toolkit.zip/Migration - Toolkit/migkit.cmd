@echo off
python "%~dp0tools\migkit.py" %*
