# ADR-NNNN: <title>

- Status: proposed | approved | superseded by ADR-XXXX
- Date: <UTC date>
- Approved by: <name>
- Decision register ID: <D-NNN>
- Run/app: <app>

## Context
What Java does today (library, version, behavior) and why this decision is needed.

## Options considered
| Option | Version | Compatibility | Maintenance | License | CVEs | Notes |
|--------|---------|---------------|-------------|---------|------|-------|

## Decision
What we chose and why.

## Behavioral differences vs Java
List each, and the mitigation (or "none").

## Consequences
Positive, negative, risks, follow-ups.
